PRICE_PER_MINUTE = 0.25   # €
DAILY_CAP = 12.0          # €


def calculate_price(minutes: int) -> float:
    """€0.25 per started minute, never more than €12."""
    if minutes < 0:
        raise ValueError("minutes must be >= 0")
    base = minutes * PRICE_PER_MINUTE
    return round(min(base, DAILY_CAP), 2)
