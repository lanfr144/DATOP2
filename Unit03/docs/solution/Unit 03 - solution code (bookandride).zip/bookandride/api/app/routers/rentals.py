import math
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..models import Rental
from ..pricing import calculate_price
from ..schemas import RentalStart, RentalStop

router = APIRouter(prefix="/rentals", tags=["rentals"])


@router.post("/start", status_code=status.HTTP_201_CREATED)
def start_rental(payload: RentalStart, db: Session = Depends(get_db),
                 x_user_id: int = Header(default=1)):
    # a bike cannot be rented twice at the same time
    busy = db.scalar(select(Rental).where(Rental.bike_id == payload.bike_id,
                                          Rental.stopped_at.is_(None)))
    if busy:
        raise HTTPException(status_code=409, detail=f"{payload.bike_id} is already rented")
    rental = Rental(user_id=x_user_id, bike_id=payload.bike_id,
                    started_at=datetime.now(timezone.utc))
    db.add(rental)
    db.commit()
    db.refresh(rental)
    return {"rental_id": rental.id, "bike_id": rental.bike_id,
            "started_at": rental.started_at.isoformat()}


@router.post("/stop")
def stop_rental(payload: RentalStop, db: Session = Depends(get_db)):
    rental = db.get(Rental, payload.rental_id)
    if rental is None:
        raise HTTPException(status_code=404, detail="Rental not found")
    if rental.stopped_at is not None:
        raise HTTPException(status_code=409, detail="Rental already stopped")
    now = datetime.now(timezone.utc)
    started = rental.started_at
    if started.tzinfo is None:                 # SQLite drops the timezone
        started = started.replace(tzinfo=timezone.utc)
    # every started minute counts
    minutes = max(1, math.ceil((now - started).total_seconds() / 60))
    rental.stopped_at = now
    rental.total_minutes = minutes
    rental.price_eur = calculate_price(minutes)
    db.commit()
    return {"rental_id": rental.id, "duration_min": minutes, "price_eur": rental.price_eur}


@router.get("")
def list_rentals(db: Session = Depends(get_db)):
    rentals = db.scalars(select(Rental).order_by(Rental.id)).all()
    return [{"rental_id": r.id, "user_id": r.user_id, "bike_id": r.bike_id,
             "started_at": r.started_at, "stopped_at": r.stopped_at,
             "price_eur": r.price_eur} for r in rentals]
