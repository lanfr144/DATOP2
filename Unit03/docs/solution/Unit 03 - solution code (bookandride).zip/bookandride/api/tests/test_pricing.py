import pytest
from app.pricing import calculate_price


def test_price_under_cap():
    assert calculate_price(40) == 10.0      # 40 × 0.25 = 10.00


def test_price_at_cap():
    assert calculate_price(48) == 12.0      # 48 × 0.25 = 12.00 exactly


def test_price_over_cap():
    assert calculate_price(100) == 12.0     # 25.00 → capped to 12.00


def test_negative_minutes_rejected():
    with pytest.raises(ValueError):
        calculate_price(-5)
