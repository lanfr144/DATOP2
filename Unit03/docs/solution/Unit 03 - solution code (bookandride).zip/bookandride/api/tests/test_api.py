import os
os.environ["DATABASE_URL"] = "sqlite:///./test.db"   # must be set BEFORE importing the app

from fastapi.testclient import TestClient
from app.main import app
from app.db import Base, engine

Base.metadata.drop_all(bind=engine)


def test_books_crud():
    with TestClient(app) as client:
        r = client.post("/books", json={"title": "Dune", "author": "Frank Herbert", "stock": 5})
        assert r.status_code == 201
        book_id = r.json()["id"]
        assert client.get("/books", params={"search": "herbert"}).json()[0]["title"] == "Dune"
        assert client.put(f"/books/{book_id}", json={"stock": 10}).json()["stock"] == 10
        assert client.delete(f"/books/{book_id}").status_code == 204
        assert client.get(f"/books/{book_id}").status_code == 404


def test_rental_flow():
    with TestClient(app) as client:
        r = client.post("/rentals/start", json={"bike_id": "BIKE-01"})
        assert r.status_code == 201
        rid = r.json()["rental_id"]
        assert client.post("/rentals/start", json={"bike_id": "BIKE-01"}).status_code == 409
        stop = client.post("/rentals/stop", json={"rental_id": rid}).json()
        assert stop == {"rental_id": rid, "duration_min": 1, "price_eur": 0.25}
